package com.classselector;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraftforge.registries.ForgeRegistries;

public class QuestTabDef {
    public String id = "", name = "", icon = "minecraft:book";
    /** Id da classe que pode ver e progredir nesta aba ("" = todas as classes). */
    public String classId = "";

    public ItemStack iconStack() {
        ResourceLocation rl = ResourceLocation.tryParse(icon);
        Item it = rl == null ? null : ForgeRegistries.ITEMS.getValue(rl);
        return new ItemStack(it == null || it == Items.AIR ? Items.BARRIER : it);
    }

    public CompoundTag save() {
        CompoundTag t = new CompoundTag();
        t.putString("id", id);
        t.putString("name", name);
        t.putString("icon", icon);
        t.putString("classId", classId);
        return t;
    }

    public static QuestTabDef load(CompoundTag t) {
        QuestTabDef d = new QuestTabDef();
        d.id = t.getString("id");
        d.name = t.getString("name");
        d.icon = t.getString("icon");
        d.classId = t.getString("classId");
        return d;
    }
}
