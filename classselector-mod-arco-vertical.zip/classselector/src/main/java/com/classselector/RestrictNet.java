package com.classselector;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.PacketDistributor;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

/** Envia ao jogador a lista de itens bloqueados para a classe dele (usa o canal de Net). */
public class RestrictNet {
    public static void register() {
        Net.CH.registerMessage(60, RSync.class, RSync::enc, RSync::dec, RSync::handle);
    }

    public record RSync(List<String> rules) {
        static void enc(RSync m, FriendlyByteBuf b) {
            b.writeVarInt(m.rules.size());
            for (String s : m.rules) b.writeUtf(s, 256);
        }
        static RSync dec(FriendlyByteBuf b) {
            int n = Math.min(b.readVarInt(), 8192);
            List<String> l = new ArrayList<>();
            for (int i = 0; i < n; i++) l.add(b.readUtf(256));
            return new RSync(l);
        }
        static void handle(RSync m, Supplier<NetworkEvent.Context> c) {
            c.get().enqueueWork(() -> RestrictClientState.set(m.rules));
            c.get().setPacketHandled(true);
        }
    }

    public static void send(ServerPlayer p, List<String> rules) {
        Net.CH.send(PacketDistributor.PLAYER.with(() -> p), new RSync(rules));
    }
}
