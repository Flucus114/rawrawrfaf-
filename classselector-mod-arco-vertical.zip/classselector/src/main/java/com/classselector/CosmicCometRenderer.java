package com.classselector;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import org.joml.Matrix3f;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;

/**
 * Desenha o Cometa Cósmico como um modelo 3D de cubos coloridos (dados em {@link CosmicCometModel}).
 * O eixo +Z do modelo aponta na direção do voo; a cauda fica atrás. Sempre brilhante (full bright).
 */
public class CosmicCometRenderer extends EntityRenderer<CosmicComet> {
    static final ResourceLocation TEXTURE =
            new ResourceLocation(ClassSelectorMod.MODID, "textures/entity/cosmic_comet.png");

    /** Escala do modelo. 1.0 = cabeça com ~0,7 bloco e cauda com ~3,4 blocos. */
    public static final float SCALE = 1.0F;

    // normais e vértices de cada face de um cubo de lado 2 (x, y, z em -1..1)
    private static final float[][] FACE_N = {
            {1, 0, 0}, {-1, 0, 0}, {0, 1, 0}, {0, -1, 0}, {0, 0, 1}, {0, 0, -1}};
    private static final float[][][] FACE_V = {
            {{1, -1, -1}, {1, 1, -1}, {1, 1, 1}, {1, -1, 1}},
            {{-1, -1, 1}, {-1, 1, 1}, {-1, 1, -1}, {-1, -1, -1}},
            {{-1, 1, -1}, {-1, 1, 1}, {1, 1, 1}, {1, 1, -1}},
            {{-1, -1, 1}, {-1, -1, -1}, {1, -1, -1}, {1, -1, 1}},
            {{-1, -1, 1}, {1, -1, 1}, {1, 1, 1}, {-1, 1, 1}},
            {{1, -1, -1}, {-1, -1, -1}, {-1, 1, -1}, {1, 1, -1}}};

    public CosmicCometRenderer(EntityRendererProvider.Context ctx) {
        super(ctx);
        this.shadowRadius = 0.0F;
    }

    @Override
    public ResourceLocation getTextureLocation(CosmicComet e) {
        return TEXTURE;
    }

    @Override
    public void render(CosmicComet e, float yaw, float pt, PoseStack ps, MultiBufferSource buf, int light) {
        float age = e.tickCount + pt;
        ps.pushPose();
        ps.translate(0.0D, e.getBbHeight() / 2.0D, 0.0D);
        // a frente do modelo (+Z, a cabeça) aponta SEMPRE para onde o cometa está indo.
        // (Não usamos yRot/xRot da entidade: bolas de fogo usam outra convenção de ângulos.)
        Vec3 d = e.getViewDir(pt);
        float yawDeg = (float) (Mth.atan2(d.x, d.z) * 57.2957795D);
        float pitchDeg = (float) (Mth.atan2(d.y, Math.sqrt(d.x * d.x + d.z * d.z)) * 57.2957795D);
        ps.mulPose(Axis.YP.rotationDegrees(yawDeg));
        ps.mulPose(Axis.XP.rotationDegrees(-pitchDeg));
        // gira devagar em torno do próprio eixo, para a cauda "cintilar"
        ps.mulPose(Axis.ZP.rotationDegrees(age * 9.0F));
        float pulse = SCALE * (1.0F + 0.05F * Mth.sin(age * 0.7F));
        ps.scale(pulse, pulse, pulse);

        VertexConsumer vc = buf.getBuffer(RenderType.entityCutoutNoCull(TEXTURE));
        drawCubes(ps.last(), vc, 0, CosmicCometModel.COUNT);
        ps.popPose();
        super.render(e, yaw, pt, ps, buf, light);
    }

    /** Desenha os cubos [from, from+count) do modelo, sempre com brilho máximo. */
    public static void drawCubes(PoseStack.Pose pose, VertexConsumer vc, int from, int count) {
        Matrix4f mat = pose.pose();
        Matrix3f nrm = pose.normal();
        int full = LightTexture.FULL_BRIGHT;
        float[] g = CosmicCometModel.GEO;
        int[] c = CosmicCometModel.COLOR;
        for (int i = from; i < from + count; i++) {
            float cx = g[i * 4], cy = g[i * 4 + 1], cz = g[i * 4 + 2], h = g[i * 4 + 3];
            int rgb = c[i];
            int r = (rgb >> 16) & 255, gr = (rgb >> 8) & 255, b = rgb & 255;
            for (int f = 0; f < 6; f++) {
                // cada face usa um texel diferente da textura 4x4 (sombreamento sutil, estilo pixel art)
                int t = (i * 7 + f * 5) & 15;
                float u = ((t & 3) + 0.5F) / 4.0F, v = ((t >> 2) + 0.5F) / 4.0F;
                float[] n = FACE_N[f];
                for (int k = 0; k < 4; k++) {
                    float[] p = FACE_V[f][k];
                    vc.vertex(mat, cx + p[0] * h, cy + p[1] * h, cz + p[2] * h)
                            .color(r, gr, b, 255)
                            .uv(u, v)
                            .overlayCoords(OverlayTexture.NO_OVERLAY)
                            .uv2(full)
                            .normal(nrm, n[0], n[1], n[2])
                            .endVertex();
                }
            }
        }
    }
}
