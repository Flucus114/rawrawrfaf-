package com.classselector;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.monster.warden.Warden;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.PacketDistributor;

import java.util.function.Supplier;

/** Avisa os clientes se um Warden domado está sentado (para a animação de sentar). */
public class WardenSitNet {
    public static void register() {
        Net.CH.registerMessage(70, WSit.class, WSit::enc, WSit::dec, WSit::handle);
    }

    public record WSit(int entityId, boolean sit) {
        static void enc(WSit m, FriendlyByteBuf b) {
            b.writeVarInt(m.entityId);
            b.writeBoolean(m.sit);
        }
        static WSit dec(FriendlyByteBuf b) {
            return new WSit(b.readVarInt(), b.readBoolean());
        }
        static void handle(WSit m, Supplier<NetworkEvent.Context> c) {
            c.get().enqueueWork(() ->
                    DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> WardenSitClient.apply(m.entityId(), m.sit())));
            c.get().setPacketHandled(true);
        }
    }

    /** Envia a todos que estão vendo o Warden. */
    public static void broadcast(Warden w, boolean sit) {
        Net.CH.send(PacketDistributor.TRACKING_ENTITY.with(() -> w), new WSit(w.getId(), sit));
    }

    /** Envia a um jogador específico (quando ele começa a ver o Warden). */
    public static void sendTo(ServerPlayer p, Warden w, boolean sit) {
        Net.CH.send(PacketDistributor.PLAYER.with(() -> p), new WSit(w.getId(), sit));
    }
}
