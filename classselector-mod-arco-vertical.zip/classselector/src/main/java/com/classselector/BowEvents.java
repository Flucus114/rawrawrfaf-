package com.classselector;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraftforge.event.entity.ProjectileImpactEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Chamado do Trovão: ao disparar, a flecha recebe uma marca com o nível do encantamento;
 * ao acertar (bloco ou criatura) cai um raio no ponto (nível 2 e 3: raios extras ao redor).
 */
@Mod.EventBusSubscriber(modid = ClassSelectorMod.MODID)
public final class BowEvents {
    private static final String TAG = "classselector_thunder_call";
    /** Raios não caem se o ponto de impacto estiver a menos de tantos blocos de quem atirou. */
    private static final double SAFE_DISTANCE = 4.0D;

    private BowEvents() { }

    private static int levelOn(ItemStack s) {
        return s.isEmpty() ? 0 : EnchantmentHelper.getTagEnchantmentLevel(ModEnchantments.THUNDER_CALL.get(), s);
    }

    @SubscribeEvent
    public static void onArrowJoin(EntityJoinLevelEvent e) {
        if (e.getLevel().isClientSide || e.loadedFromDisk()) return;
        if (!(e.getEntity() instanceof AbstractArrow arrow) || !(arrow.getOwner() instanceof LivingEntity owner)) return;
        int lvl = levelOn(owner.getUseItem());
        if (lvl <= 0) lvl = levelOn(owner.getMainHandItem());
        if (lvl <= 0) lvl = levelOn(owner.getOffhandItem());
        if (lvl > 0) arrow.getPersistentData().putInt(TAG, lvl);
    }

    @SubscribeEvent
    public static void onImpact(ProjectileImpactEvent e) {
        if (!(e.getProjectile() instanceof AbstractArrow arrow)) return;
        if (!(arrow.level() instanceof ServerLevel level)) return;
        int lvl = arrow.getPersistentData().getInt(TAG);
        if (lvl <= 0) return;
        arrow.getPersistentData().remove(TAG); // só uma vez por flecha

        Vec3 at = e.getRayTraceResult().getLocation();
        LivingEntity owner = arrow.getOwner() instanceof LivingEntity l ? l : null;
        callThunder(level, at, owner, lvl);
    }

    /** Raios no ponto (nível 1 = 1 raio; 2 e 3 = raios extras ao redor). Não cai perto de quem atirou. */
    public static void callThunder(ServerLevel level, Vec3 at, LivingEntity owner, int lvl) {
        if (owner != null && owner.position().distanceTo(at) < SAFE_DISTANCE) return;
        strike(level, at, owner);
        for (int i = 1; i < lvl; i++) {
            double ang = level.random.nextDouble() * Math.PI * 2.0D;
            double r = 2.0D + level.random.nextDouble() * 2.0D;
            strike(level, at.add(Math.cos(ang) * r, 0.0D, Math.sin(ang) * r), owner);
        }
    }

    private static void strike(ServerLevel level, Vec3 pos, LivingEntity owner) {
        LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(level);
        if (bolt == null) return;
        bolt.moveTo(Vec3.atBottomCenterOf(BlockPos.containing(pos)));
        if (owner instanceof ServerPlayer sp) bolt.setCause(sp);
        level.addFreshEntity(bolt);
    }
}
